<?php

namespace App\Http\Controllers\admin;
use Illuminate\Support\Facades\Auth;    
use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Category;
class DashboardContoller extends Controller
{

    public function __construct()
    {
        if(!Auth::check()){
            return redirect('/');
        }  
        
    }
    public function index(){
	    $courses_count = Course::count();
	    $courses = Course::orderBy('cnum','desc')->limit(5)->get();
        $categories_count = Category::count();
      
        return view('admin/pages/dashboard')->with([
            'courses' => $courses,
            'courses_count' => $courses_count,
            'categories_count' => $categories_count,
        ]); 
    }
}
