<?php

namespace App\Http\Controllers\admin;
use Illuminate\Support\Facades\Auth;    
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Theme;
use PDF;
use File;
use Excel;
use Image;
use App\Imports\StudentsImport;
use App\Models\Student;
use Illuminate\Support\Facades\URL;

class CertificatesController  extends Controller
{
    public function __construct()
    {
        if(!Auth::check()){
            return redirect('/');
        }  
        
    }

    public function index(){
    
        $themes = Theme::all();
      
        return view('admin/pages/certificates')->with([
            'themes' => $themes
        ]);
    }

    public function new(){

      return view('admin/pages/certificate-new')->with([]);
    }

    public function edit($id){
	    $theme = Theme::find($id);
      $img = Image::make(public_path("public/images/" . $theme->back_imge));

      $img->save(public_path("public/images/BgCertificate.jpg")); 

        return view('admin/pages/certificate-edit')->with([
            'theme' => $theme,
        ]);
    }


    public function viewer(Request $request) {

        // create Image from file
        $img = Image::make(public_path('public/images/BgCertificate.jpg'));

        $student_name =  $request->get('student_name');
        $student_name_x =  $request->get('student_name_x') ??  220;
        $student_name_y =  $request->get('student_name_y') ??  220;
        $student_name_font_size =  $request->get('student_name_font_size') && $request->get('student_name_font_size') > 0 ?   $request->get('student_name_font_size') : 30;
        $student_name_font_color =  $request->get('student_name_font_color') ??  '000';
        if($student_name){
            $img->text($student_name, $student_name_x ,$student_name_y, function ($font) use($student_name_font_color,$student_name_font_size ) {
              $font->file(app()->publicPath() . '/Arial.ttf');
              $font->color('#' . $student_name_font_color);
              $font->align('center');
              $font->valign('middle');
              
              $font->size($student_name_font_size );
            });
        }

        $student_national_number =  $request->get('student_national_number');
        $student_national_number_x =  $request->get('student_national_number_x') ??  285;
        $student_national_number_y =  $request->get('student_national_number_y') ??  295;
        $student_national_number_font_size =  $request->get('student_national_number_font_size') && $request->get('student_national_number_font_size') > 0 ?   $request->get('student_national_number_font_size') : 30;
        $student_national_number_font_color =  $request->get('student_national_number_font_color') ??  '000';
        if($student_national_number){
          $img->text($student_national_number, $student_national_number_x ,$student_national_number_y, function ($font) use($student_national_number_font_color,$student_national_number_font_size ) {
              $font->file(app()->publicPath() . '/Arial.ttf');
              $font->color('#' . $student_national_number_font_color);
              $font->align('center');
              $font->valign('middle');
              
              $font->size($student_national_number_font_size );
            });
        }

        $student_mobile_number =  $request->get('student_mobile_number');
        $student_mobile_number_x =  $request->get('student_mobile_number_x') ??  220;
        $student_mobile_number_y =  $request->get('student_mobile_number_y') ??  220;
        $student_mobile_number_font_size =  $request->get('student_mobile_number_font_size') ??  30;
        $student_mobile_number_font_color =  $request->get('student_mobile_number_font_color') ??  '#000';
        if($student_mobile_number){
            $img->text($student_mobile_number, $student_mobile_number_x ,$student_mobile_number_y, function ($font) use($student_mobile_number_font_color,$student_mobile_number_font_size ) {
              $font->file(app()->publicPath() . '/Arial.ttf');
              $font->color( $student_mobile_number_font_color );
              $font->align('center');
              $font->valign('middle');
              $font->size($student_mobile_number_font_size );
            });
        }

        $student_email =  $request->get('student_email');
        $student_email_x =  $request->get('student_email_x') ??  220;
        $student_email_y =  $request->get('student_email_y') ??  220;
        $student_email_font_size =  $request->get('student_email_font_size') && $request->get('student_email_font_size') > 0 ?   $request->get('student_email_font_size') : 30;
        $student_email_font_color =  $request->get('student_email_font_color') ??  '#000';
        if($student_email){
            $img->text($student_email, $student_email_x ,$student_email_y, function ($font) use($student_email_font_color,$student_email_font_size ) {
              $font->file(app()->publicPath() . '/Arial.ttf');
              $font->color( $student_email_font_color );
              $font->align('center');
              $font->valign('middle');
              
              $font->size($student_email_font_size );
            });
        }

        // create instance
        $img_qr = Image::make(public_path('public//QR_code_for_mobile_English_Wikipedia.svg.png'));


        $qr_x =  $request->get('qr_x') ??  40;
        $qr_y =  $request->get('qr_y') ??  45;
        $qr_size =  $request->get('qr_size') &&  $request->get('qr_size') > 0 ?  $request->get('qr_size') : 60;
        $qr_position =  $request->get('qr_position') ??  'bottom-left';
        // resize image to fixed size
        $img_qr->resize($qr_size, $qr_size);

        $img_qr->save(public_path('public/images/qr-demo.png')); 

        $img->insert(public_path('public/images/qr-demo.png'), $qr_position, $qr_x, $qr_y);

        $img->save(public_path('public/images/demo.png')); 

        return view('admin/pages/viewer')->with([]);
      
    }
  
    public function download(Request $request){

      
      if (! $request->hasValidSignature()) {
        abort(401);
      }
      $theme_id =  $request->theme_id ??  null;
      $student_id =  $request->student_id ??  null;
      $course_id =  $request->course_id ??  null;

      if(!$theme_id || !$student_id  || !$course_id){
        abort(401);
      }
      $theme = Theme::find($theme_id);
      $student = Student::find($student_id);

      

      $img = Image::make(public_path("public/images/" . $theme->back_imge));

      $student_name =  $student->name;
      $student_name_x =  $theme->student_name_x ??  220;
      $student_name_y =  $theme->student_name_y ??  220;
      $student_name_font_size =  $theme->student_name_font_size && $theme->student_name_font_size > 0 ?   $theme->student_name_font_size : 30;
      $student_name_font_color =  $theme->student_name_font_color  && $theme->student_name_font_color > 0 ? $theme->student_name_font_size :  '000';
      if($student_name){
          $img->text($student_name, $student_name_x ,$student_name_y, function ($font) use($student_name_font_color,$student_name_font_size ) {
            $font->file(app()->publicPath() . '/Arial.ttf');
            $font->color('#' . $student_name_font_color);
            $font->align('center');
            $font->valign('middle');
            
            $font->size($student_name_font_size );
          });
      }

      $student_national_number =  $theme->student_national_number ? $student->national_number : null;
      $student_national_number_x =  $theme->student_national_number_x ??  285;
      $student_national_number_y =  $theme->student_national_number_y ??  295;
      $student_national_number_font_size =  $theme->student_national_number_font_size && $theme->student_national_number_font_size > 0 ?   $theme->student_national_number_font_size : 30;
      $student_national_number_font_color =  $theme->student_national_number_font_color  && $theme->student_national_number_font_color > 0 ? $theme->student_national_number_font_color :  '000';

      if($student_national_number){
        $img->text($student_national_number, $student_national_number_x ,$student_national_number_y, function ($font) use($student_national_number_font_color,$student_national_number_font_size ) {
            $font->file(app()->publicPath() . '/Arial.ttf');
            $font->color('#' . $student_national_number_font_color);
            $font->align('center');
            $font->valign('middle');
            
            $font->size($student_national_number_font_size );
          });
      }

      

      // create instance
      $img_qr = Image::make(public_path('public/QR_code_for_mobile_English_Wikipedia.svg.png'));


      $qr_x =  $theme->qr_x ??  40;
      $qr_y =  $theme->qr_y ??  45;
      $qr_size =  $theme->qr_size &&  $theme->qr_size > 0 ?  $theme->qr_size : 60;
      $qr_position =  $theme->qr_position ??  'bottom-left';
      // resize image to fixed size
      $img_qr->resize($qr_size, $qr_size);

      $img_qr->save(public_path('public/images/qr-demo.png')); 

      $img->insert(public_path('public/images/qr-demo.png'), $qr_position, $qr_x, $qr_y);

      $path = public_path("public/images/{$course_id}");
      File::deleteDirectory($path);
      File::isDirectory($path) or File::makeDirectory($path, 0777, true, true);
      $img->save(public_path("public/images/{$course_id}/view.png")); 


      
      return view('admin/pages/download')->with([]);;


    
    }
  

    public function QrCode(Request $request){

        $student_name = $request->get('student_name') ??  "Student Name";

        return view('admin/pages/QrCode')->with([
            'student_name' => $student_name,
        ]);
    }


    public function importStudents(Request $request){

    

      $array = Excel::import(new StudentsImport($request->course_id),$request->file);

      return  redirect()->back()->with('status', 'Student updated!');

    
    }

    public function importBgCertificate(Request $request){


      $img = Image::make($request->file);
      $img->save(public_path('public/images/BgCertificate.jpg'));

      return  redirect()->back()->with('status', 'Student updated!');

    
    }


        
}
